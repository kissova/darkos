#pragma once

// =============================================================================
// PUBG Mobile Global 4.7.0 (4.7.0 -- 64-Bit) SDK
// Copyright (C) 2026 Zervex RIYAZ. All Rights Reserved.
// Developed by: @Zervexcheat RIYAZ (TG: @RIYAZXERO | Channel: @RIYAZ_STUFF)
// GitHub: https://github.com/RIYAZXERO
// Generation Time: Thu Nov 12 22:34:24 2026

// =============================================================================

namespace SDK
{
//---------------------------------------------------------------------------
// Script Structs
//---------------------------------------------------------------------------

// UserDefinedStruct BP_STRUCT_Client120FPSExpandMapping_type.BP_STRUCT_Client120FPSExpandMapping_type
// 0x0038
struct FBP_STRUCT_Client120FPSExpandMapping_type
{
	int                                                ID_0_43452A8067B55B5E0CB38F2B00D093B4;                    // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0004(0x0004) MISSED OFFSET
	struct FString                                     MaxFPSByQuality_1_2958F40001887B921A3E5A4F090C2CD9;       // 0x0008(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     ModelNames_2_784A808077F4CA90549441AA0CA026B3;            // 0x0018(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     RecommendFPS_3_58A368001D690F9C2374E792016FDDE3;          // 0x0028(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
};

}

